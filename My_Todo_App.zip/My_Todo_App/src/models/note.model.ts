export interface Note {
    title: string
    content: string
    date: Date
    createDate: number
}