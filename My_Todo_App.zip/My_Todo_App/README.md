# ion-notes
A basic note-taking application built with Ionic

I created a YouTube video series demonstrating building this app:
[YouTube series playlist](https://www.youtube.com/watch?v=qa7AYCVY-aA&list=PL3_YUnRN3UhhoRDxB5civwI4_MY7PL9Bx)


